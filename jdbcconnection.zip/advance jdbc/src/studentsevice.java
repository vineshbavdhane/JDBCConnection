import java.sql.SQLException;
import java.util.ArrayList;

public class studentsevice {

	static ArrayList<student>fetchStudents() throws ClassNotFoundException, SQLException {
    	ArrayList<student>alStu=studentdao.fetchstudents();
		
    	ArrayList<student>alStufiltered=new ArrayList<student>();
    	
		for(student student:alStu){
			if(student.name.startsWith("s")){
				alStufiltered.add(student);
		} 
		}
	return alStufiltered;
		 

	}

}
