import java.util.ArrayList;

public class studentclint {
	public static void main(String[] args) throws Exception {
    ArrayList<student>al=studentcontroller.fetchstudents();
for(student student:al){
	System.out.println(student.rollno);
	System.out.println(student.name);
}
}
}