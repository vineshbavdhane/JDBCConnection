import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class studentdao {
static	ArrayList<student> fetchstudents() throws SQLException, ClassNotFoundException{
	Class.forName("com.mysql.jdbc.Driver");
Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/Student","root","root");
	
	String sql="select*from student";
	Statement stm=connection.createStatement();
	ResultSet resultset=stm.executeQuery(sql);
    ArrayList<student>alStu=new ArrayList<student>();
	while(resultset.next()){ 
	  int rollno=resultset.getInt(1);
	String name= resultset.getString(2);
  student student=new student(rollno,name);
	 System.out.println("rollno :"+rollno);
	 System.out.println("name  :  "+name);

	}
	return alStu;

	}
}
