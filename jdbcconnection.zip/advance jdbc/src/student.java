
public class student {
	int rollno;
	String name;
	public student(int rollno, String name) {
		super();
		this.rollno = rollno;
		this.name = name;
	}
	public int getId() {
		return rollno;
	}
	public void setId(int rollno) {
		this.rollno = rollno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "imploye[id="+rollno+",name="+name+"]";
	}
	
	


}
