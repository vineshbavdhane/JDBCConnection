import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class jdbc {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
	
		
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/imploye","root","root");
		
		String sql="select*from imploye";
		Statement stm=connection.createStatement();
		ResultSet resultset=stm.executeQuery(sql);

		while(resultset.next()){ 
		 String id=resultset.getString(1);
		String name= resultset.getString(2);
		
		 System.out.println("id no :"+id);
		 System.out.println("name  :  "+name);
	
		}
		
	}
		
	}
	


