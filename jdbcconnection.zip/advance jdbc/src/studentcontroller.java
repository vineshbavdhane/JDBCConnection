import java.sql.SQLException;
import java.util.ArrayList;

public class studentcontroller {
static ArrayList<student>fetchstudents() throws ClassNotFoundException, SQLException{
	ArrayList<student>alStu=studentdao.fetchstudents();
	return alStu;
}


}


